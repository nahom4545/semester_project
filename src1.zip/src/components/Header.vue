<template>
    <div>
      <img src="../assets/bit.jpg" alt="">
    <nav
      class="px-6 py-8 bg-sky-900 md:flex md:justify-between md:items-center h-30"
    >
      <div class="flex items-center justify-between">
      
        <!-- Mobile menu button -->
        <div @click="toggleNav" class="flex md:hidden">
          <button type="button"  class=" text-gray-100 hover:text-gray-400 focus:outline-none focus:text-gray-400">
            <svg viewBox="0 0 24 24" class="w-6 h-6 fill-current">
              <path
                fill-rule="evenodd"
                d="M4 5h16a1 1 0 0 1 0 2H4a1 1 0 1 1 0-2zm0 6h16a1 1 0 0 1 0 2H4a1 1 0 0 1 0-2zm0 6h16a1 1 0 0 1 0 2H4a1 1 0 0 1 0-2z"
              ></path>
            </svg>
          </button>
        </div>
      </div>

      <!-- Mobile Menu open: "block", Menu closed: "hidden" -->
      <ul
        :class="showMenu ? 'flex' : 'hidden'" class="   flex-col  mt-8     space-y-4 md:flex md:space-y-0 md:flex-row md:items-center md:space-x-10 md:mt-0 "
      >
        <li class="text-gray-100 hover:text-indigo-400">Home</li>
        <li>
          <div class="relative">
            <!-- Dropdown toggle button -->
            <button  @click="show = !show" class="   flex      items-center   text-indigo-100  bg-sky-900       rounded-md focus:outline-none">

              <span class="mr-4">Faculties</span>
              <svg class="w-5 h-5 text-indigo-100" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"  fill="currentColor"
              >
             <path
                  fill-rule="evenodd"
                  d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                  clip-rule="evenodd"  />
           </svg>
         </button>

            <!-- Dropdown menu -->
            <div v-show="show"     class="   py-2  mt-2  bg-sky-900     rounded-md  shadow-xl   lg:absolute lg:right-0    w-44" >
            <router-link
                to="/" class="  block px-4  py-2 text-sm text-indigo-100 hover:bg-indigo-400 hover:text-indigo-100" >
                Faculty of computing
              </router-link>
              <router-link
                to="/" class="  block px-4  py-2 text-sm text-indigo-100 hover:bg-indigo-400 hover:text-indigo-100" >
               Faculty of Checmical and food Engineering
              </router-link>
              <router-link
                to="/" class="  block px-4  py-2 text-sm text-indigo-100 hover:bg-indigo-400 hover:text-indigo-100" >
            Faculty of Civil and water Resource Engineering
              </router-link>
              <router-link
                to="/" class="  block px-4  py-2 text-sm text-indigo-100 hover:bg-indigo-400 hover:text-indigo-100" >
              Faculty of Electrical and Computer Engineering
              </router-link>
              <router-link
                to="/" class="  block px-4  py-2 text-sm text-indigo-100 hover:bg-indigo-400 hover:text-indigo-100" >
               Faculty of Mechanical and Industrial Engineering
              </router-link>
             
            </div>
          </div>
        </li>
        <li class="text-gray-100 hover:text-indigo-400">Best Projects</li>
        <li class="text-gray-100 hover:text-indigo-400">Contact Adivisor</li>
        <li class="text-gray-100 hover:text-indigo-400"><router-link to="/FileUpload" class="text-gray-100 hover:text-indigo-400"> Upload Project</router-link></li>
        <li class="text-gray-100 hover:text-indigo-400">More Information</li>
        <li class="text-gray-100 hover:text-indigo-400">Comments</li>
        <li class="text-gray-100 hover:text-indigo-400"><router-link to="/SignUp" class="text-gray-100 hover:text-indigo-400"> Login</router-link></li>
        <li class="text-gray-100 hover:text-indigo-400"><button v-on:click="logout">LogOut</button></li>
      </ul>
    </nav>
  </div>
</template>

<script>
  import { ref } from 'vue'
    export default {
        name:'HeaderPage',
    setup() {
    let showMenu = ref(false);
      let show = ref(false);
      const toggleNav = () => (showMenu.value = !showMenu.value);
      return { showMenu, show, toggleNav };
    },
    methods:{
      logout(){
        localStorage.clear();
        this.$router.push({name: 'LogIn'})
      }
    }
    }
</script>

<style scoped>

</style>