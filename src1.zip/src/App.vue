<template>
  <Header></Header>
  <nav>
    <router-link to="/">Home</router-link> |
    <router-link to="/about">About</router-link> | 
    <router-link to="/FileUpload" text-white-700>File Upload</router-link> | 
    <router-link to="/SignUp">SignUp</router-link>   |   
    <router-link to="/Admin">Admin Panel</router-link>  |   
    <router-link to="/SearchBar">Check By Search</router-link> |  
    <router-link to="/ProjectList">Previous Projects</router-link> |  
    <router-link to="/TitleSubmission" text-white-700>Submit Project title</router-link> |  
    <router-link to="/Login">Login</router-link> |  
    <router-link to="/DownloadFile">Download File</router-link> | 
    <router-link to="/UploadInfo">Upload Info</router-link> |
    <router-link to="/Signlist">Sign list</router-link> |
    <router-link to="/Notices">Notices</router-link> |
    <router-link to="/NoticeAdmin">Notice Admin</router-link> |
    <router-link to="/SignAdmin">Sign Admin</router-link> |
    <router-link to="/AdvisorProfile">Advisor signup</router-link> |


    

     

    <a href="#" v-on:click="logout">Logout</a>  |  

  </nav>

  <router-view/>
 <!-- <div id="app">
    <input type="text" v-model="search" style="border: 1px black solid ">
    <div v-for="post in filteredPosts" :key="post.id">
      <post :post="post"></post>
    </div>
  </div>
<br><br><br><br><br>
-->
<!--<WebViewer initailDoc="http://localhost:8080/files/trial2.pdf"></WebViewer> -->
<Footer></Footer>

</template>
<script>

import Footer from './components/Footer.vue'
import Header from './components/Header.vue'
import SearchBar from './views/SearchBar.vue'
import UploadFile from './components/UploadFile.vue'


export default {
  name: 'App',
 components:{
  Footer,
  Header,
  SearchBar,

  UploadFile,
 
 },
 data() {
      return {
        search: "",
        posts: [
          {
            id: 2010,
            title: "Cancer Diseases detection",
            body: "Hello This is trial"
          },
          {
            id: 2,
            title: "Post 2",
            body: "Javascript is cool"
          }
        ]
      };
    },
    methods:{
      logout(){
         localStorage.clear();
         this.$router.push({name:"/SignUp"});
      }
    },
    computed: {
      filteredPosts() {
        return this.posts.filter(post =>
          post.body.toLowerCase().includes(this.search.toLowerCase())
        );
      }
    }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

nav {
  padding: 30px;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
}

nav a.router-link-exact-active {
  color: #42b983;
}
</style>
