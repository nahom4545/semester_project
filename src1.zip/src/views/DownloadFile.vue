<template>

 
    <div class="ml-80 mr-80">
      <div class="flex flex-col">
      <div class="overflow-x-auto sm:-mx-6 lg:-mx-8">
        <div class="py-2 inline-block min-w-full sm:px-6 lg:px-8">
          <div class="overflow-x-auto">
            <table class="min-w-full">
              <thead class="border-b">
                <tr>
                  <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-center bg-gray-300">
                    Files
                  </th>
                 
                  <th scope="col" class="text-sm font-medium text-gray-900  text-center bg-gray-300">
                  View
                  </th>
                  
                </tr>
              </thead>
              <tbody>
                <tr class="border-b"  v-for="item in items" :key="item.name">
                
                  <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                  {{ item.name }}
                  </td>
                  <td class="text-sm text-gray-900 font-light whitespace-nowrap ">
                   <a :href="item.url" class="text-sky-500 hover:bg-sky-700">open</a> 
             
                 
                  </td>
                 </tr>
                
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    </div>
      <br><br> <br><br><br>

    </template>
    
    <script >
    //import axios
    import axios from "axios";
    export default {
      name:'DownloadFile',
      data() {
        return {
          items: [],
        };
      },
  
      created() {
        this.fetchfiles();
      },
      methods: {
        //get all products
        async fetchfiles() {
          try {
            const response = await axios.get("http://localhost:5000/files");
            this.items = response.data;
            console.log(this.items);
          } catch (err) {
            console.log(err);
          }
        },
        deleteFile(){
          if(confirm("Are you sure you want delete this file?"))  {
          try{
          
            axios.delete(`remove/sample3.pdf`)
              }
              catch(err){
              console.log(err);
            }
            }
          }
      },
      mounted(){
   let user= localStorage.getItem('user-info')
   if(!user){
    this.$router.push({name:'Login'})
   }
  }
    };
    </script>
    
    
    