<template>
  <div class="about">
  <div class="m-4 px-4 bg-gray-100 justify-center " >

  
<h2 style="font-size:40px">
Background
</h2>
<h3 style="font-size:30px">
Bahir Dar Institute of Technology (BiT) 
</h3>
<p>
Bahir Dar University is one of the largest and well-known public universities in Ethiopia. 
The university was established on May 6, 2000 by merging two public higher institutions namely Bahir Dar Polytechnic
and Bahir Dar Teachers’ College. Currently,
the university has five institutes, five colleges, two academies, six faculties and two schools. Bahir Dar Institute of Technology, 
which is one of the institutes in Bahir Dar University, is among the oldest and well-known technology institutes in Ethiopia. The institute
was founded by a bilateral agreement between the Ethiopian and former Soviet Union governments in 1963. It was planned to admit top ranked
students who successfully passed the eighth-grade national examination. Following its establishment as polytechnic institute, it admitted 232
students for four-year programs. Since then, the institute had undergone several program changes within the area of technology (Agro-mechanics, 
Industrial Chemistry, Metal, Textile, Electrical and Wood Technologies).
In 2011, the institute was upgraded to Bahir Dar Institute of Technology (BiT).  
</p>
<p>
The institute has been contributing to the labor market with graduates who are now running most of the businesses in the industrial, educational, agricultural and other economic development sectors in Ethiopia and working abroad. Since its establishment, it became a pioneer institute of technology offering higher education in the field of engineering and technology. The institute aspires to become a leading institute in engineering and technology programs that prepare students to become entrepreneurs, and innovators through a distinct education. Currently, 4675 students are enrolled in 18 undergraduate programs and about 1869 postgraduate students in 38 Msc programs and 138 students in 26 PhD programs. It has well equipped 44 laboratories supporting research and practical teaching and to deliver different technical support to partners and our main stakeholders in the region. 
</p>
<p>
The institute is working towards solving practical problems of community and teaching practically oriented courses through an ample experience in teaching, research and community service. Furthermore, it is also envisioned to have a national impact through the dissemination of technologies focused on the need of the local community and industrial sector. The institute has many international and national partners which are working towards facilitating teaching, research and community service activities. The teaching, research and community service activities are supported by high qualified instructors, technical assistants, and administrative staff.
</p>
</div>
</div>
</template>
