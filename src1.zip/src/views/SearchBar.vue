<template>
 
<form class="flex items-center w-5/6">   
    <label for="simple-search" class="sr-only">Search</label>
    <div class="relative w-full">
        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <svg aria-hidden="true" class="w-5 h-5 text-gray-500 dark:text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clip-rule="evenodd"></path></svg>
        </div>
        <input type="text" id="simple-search" v-model="custom_count_query"
        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 p-2.5  dark:bg-gray-200 dark:border-gray-600 dark:placeholder-gray-400 dark:text-black dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Search" required>
    </div>
    <button type="submit" class="p-2.5 ml-2 text-sm font-medium text-white bg-blue-700 rounded-lg border border-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
        <span class="sr-only">Search</span>
    </button>
</form>

  
<div id="app">
  <input type="text" v-model="custom_count_query" placeholder="Enter custom count item here.">
  <input type="number" placeholder="" v-model="customcount">
  <input type="checkbox" id="no_spaces" v-model="case_sen">case sensitive
  <table >
    <tr>
      <th>Character</th>
      <th>Word</th>
      <th>Sentence</th>
      <th>Line</th>
    </tr>
    <tr>
      <td>{{char_count}}</td>
      <td>{{word_count}}</td>
      <td>{{sentence_count}}</td>
      <td>{{line_count}}</td>
    </tr>
  </table>
  <table> 
    <tr>
      <th>Word</th>
      <th>Word Count</th>
      <th>Percent</th>
    </tr>
    <tr v-for="word in wrdfrq">
      <td>{{word.title}}</td>
      <td>{{word.wordCount}}</td>
      <td>{{word.wordCountPercent}}</td>
    </tr>
  </table>
  
  <input type="checkbox" id="no_spaces" v-model="no_spaces">
  <label for="no_spaces">Space</label>
  <input type="checkbox" title="Do not count HTML tags." id="skip_html" v-model="skip_html">
  <label for="no_spaces">HTML tags.</label>
  <input type="checkbox" id="linebreak_as_space" v-model="linebreak_as_space" >
  <label for="linebreak_as_space">Count line breaks as spaces.</label>

  <div class="flex flex-col bg-gray-300" >
  <div class="overflow-x-auto sm:-mx-6 lg:-mx-8">
    <div class="py-2 inline-block min-w-full sm:px-6 lg:px-8">
      <div class="overflow-x-auto">
        <table class="min-w-full">
          <thead class="border-b">
            <tr>
              <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-left">
                Character
              </th>
              <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-left">
                Word
              </th>
              <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-left">
              Sentence
              </th>
              <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-left">
               Line
              </th>
             
            </tr>
          </thead>
          <tbody>
            <tr class="border-b">
              <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{{char_count}}</td>
              <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                {{word_count}}
              </td>
              <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                {{sentence_count}}
              </td>
              <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                {{line_count}}
              </td>
            
            </tr>
           
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

  
<label for="message" class="block mb-2 text-sm font-medium text-gray-300 dark:text-white">Your message</label>
<textarea id="input" v-model="input" cols="50"  rows="10"
class="block p-2.5  text-sm bg-white-50 rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-white-300 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Write your thoughts here..."></textarea>

</div>


  
  <br><br>  <br><br><br> <br><br>  <br><br><br><br>
  </template>
  <script>
  
  
  export default {
    name: 'SignUp',
    data(){
    return{
      input: '',
      skip_html: false,
      linebreak_as_space: false,
      no_spaces: false,
      linebreak_as_space: false,
      custom_count_query: '',
      case_sen: false,
    }
  },
  computed:{
    customcount(){
      var vm = this
      var filecont = vm.input;
      if(vm.skip_html) filecont = filecont.replace(/<\S[^><]*>/gi,'');
      var cst_cnt = 0;
      var customcntflags = 'gi';
      if(vm.case_sen) customcntflags = 'g';
      var regxin = vm.custom_count_query.replace(/([.*+?^=!:${}()|\[\]\/\\])/g,'\\$1');
      if(regxin != ''){
        var customcnt = new RegExp(regxin,customcntflags);
        var custc = filecont.replace(/\r/g,'').match(customcnt);
        if(custc != null) cst_cnt = custc.length; else cst_cnt = '0';} else cst_cnt = '0';
      return cst_cnt;
    },
    word_count(){
      var vm = this,
          filecont = vm.input;
      return vm.skip_html && (filecont = filecont.replace(/<\S[^><]*>/gi, "")),
        vm.input.match(/\w+/g) ? vm.input.match(/\w+/g).length : 0;
    },
    line_count(){
      var vm = this,
          filecont = vm.input;
      return vm.skip_html && (filecont = filecont.replace(/<\S[^><]*>/gi, "")),
        vm.input.match(/\n/g) ? vm.input.match(/\n/g).length + 1 : 0;

    },
    char_count(){
      var vm = this
      var filecont = vm.input,
          chr_cnt  = 0;
      vm.skip_html && (filecont = filecont.replace(/<\S[^><]*>/gi, ""));
      vm.linebreak_as_space ||
        vm.no_spaces ||
        (chr_cnt = filecont.replace(/[\r\n]/g, "").length);
      vm.no_spaces && (chr_cnt = filecont.replace(/[\r\n\s]/g, "").length);
      vm.linebreak_as_space &&
        (chr_cnt = filecont.replace(/\r/g, "").replace(/\n/g, " ").length);
      return chr_cnt
    },
    sentence_count() {
      var a = this,
          b = a.input.replace(/\r/g, "").replace(/ \n/g, "\n") + "\n",
          c = b.split(". ").length - 1,
          d = b.split(".\n").length - 1,
          e = b.split("! ").length - 1,
          f = b.split("!\n").length - 1,
          g = b.split("? ").length - 1,
          h = b.split("?\n").length - 1;
      return c + d + e + f + g + h;
    },
    wrdfrq(fun){
      var vm = this
      var textin = vm.input.toLowerCase();
      if(vm.skip_html) textin = textin.replace(/<\S[^><]*>/gi,'');
      var wrdarr = textin.match(/\b(\w|')+\b/g);

      var dupsremarr = new Array();
      var dupsremarrcnt = 0;
      var hash = {};
      var xkey = '';
      var hkey = '';
      var wrdcht = 0;
      var wrdcntpct = 0;
      if(wrdarr){
        var wrdarrlen =  wrdarr.length;
        for(var x=0;x<wrdarrlen;x++){
          xkey = wrdarr[x];
          hkey = ' ' + xkey;
          if(hash[hkey] == null || xkey == '') {hash[hkey] = x+1; dupsremarr[dupsremarrcnt] = xkey; dupsremarrcnt++;}}
        wrdarr = ' ' + wrdarr.join(' ') + ' ';
      }

      for(var x=0;x<dupsremarrcnt;x++){
        wrdcht = (wrdarr.split(' ' + dupsremarr[x] + ' ').length) - 1;
        wrdcntpct = (wrdcht / wrdarrlen) * 100;
        wrdcntpct = parseFloat(wrdcntpct).toFixed(2);
        dupsremarr[x] = { title: dupsremarr[x], wordCount: wrdcht, wordCountPercent: wrdcntpct}
      }
      return dupsremarr
    }
  }

  
  }
  </script>
  <style>
table, th, td {
  border: 1px solid black;
}
</style>