<template>
  
           
    <div class="ml-80 mr-80">
      <div class="flex flex-col">
      <div class="overflow-x-auto sm:-mx-6 lg:-mx-8">
        <div class="py-2 inline-block min-w-full sm:px-6 lg:px-8">
          <div class="overflow-x-auto">
            <table class="min-w-full">
              <thead class="border-b">
                <tr>
                  <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-center bg-gray-300">
                    Name
                  </th>
                 
                  <th scope="col" class="text-sm font-medium text-gray-900  text-center bg-gray-300">
                  Email
                  </th>
                  <th scope="col" class="text-sm font-medium text-gray-900  text-center bg-gray-300">
                  Password
                  </th>
                  <th scope="col" class="text-sm font-medium text-gray-900  text-center bg-gray-300">
                  Action
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr class="border-b"  v-for="item in signupinfo" :key="item.id">
                
                  <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                  {{ item.name }}
                  </td>
                  <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                  {{ item.email }}
                  </td>
                  <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                  {{ item.password }}
                  </td>
                  <td class="text-sm text-gray-900 font-light whitespace-nowrap ">

                    
                    <button  @click="deleteAccount(item.id)"><img src="../assets/delete.png" alt="delete" width="30" height="50"> </button>
                    <a href="#" class=" mb-5 ml-5 inline-flex items-center px-3 py-2 text-sm font-medium text-center text-white bg-blue-700 rounded-lg hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                        <!-- <router-link to="/UpdateAccount">update Account</router-link> | -->Update
</a>
                 
                  </td>
                 </tr>
                
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    </div>
         
        
        
        </template>
        <script >
        import axios from "axios";
        export default{
            name:'signAdmin',
            data() {
                return {
                 
                    signupinfo: [],
                   
                    
                }
            },
            created(){
                this.noticeList();
            },
        
         methods: {
        async noticeList(){
            await axios.get('http://localhost:5000/signup')
            .then(response => {
              this.signupinfo = response.data;
            })
            .catch(error => console.log(error))
        },
        
        deleteAccount(id){
             axios.get(`http://localhost:5000/deleteaccount/${id}`)
            .then(response => {
              this.notices = response.data;
            })
            .catch(error => console.log(error))
           }
         },


        
        
       //  computed: {
       //      filteredList() {
       //        return this.names.filter(post => {
       //          return post.name.toLowerCase().includes(this.query.toLowerCase())
       //        })
       //      }
       //      }
          
       //  
    }

        </script>