<template>
   <section class="h-screen bg-gray-300">
  <div class="px-6 h-full text-gray-800">
    <div
      class="flex xl:justify-center lg:justify-between justify-center items-center flex-wrap h-full g-6"
    >
  
      <div class="xl:ml-20 xl:w-5/12 lg:w-5/12 md:w-8/12 mb-12 md:mb-0">
      
        <form >
        
          <!-- Email input -->
          <div class="mb-6">
            <input
              type="number"
              class="form-control block w-full px-4 py-2 text-xl font-normal text-gray-700 bg-white bg-clip-padding border border-solid border-gray-300 rounded transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none"
              id="exampleFormControlInput2"
              placeholder="Enter your id"
              v-model="username"
            />
          </div>

          <!-- Password input -->
          <div class="mb-6">
            <input
              type="text"
              class="form-control block w-full px-4 py-2 text-xl font-normal text-gray-700 bg-white bg-clip-padding border border-solid border-gray-300 rounded transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none"
              id="exampleFormControlInput2"
              placeholder="Password"
              v-model="password"
            />
          </div>

          <div class="flex justify-between items-center mb-6">
            <div class="form-group form-check">
              
            </div>
            <a href="#!" class="text-gray-800">Forgot password?</a>
          </div>

          <div class="text-center lg:text-left">
            <button
              type="button"
              class="inline-block px-7 py-3 bg-blue-600 text-white font-medium text-sm leading-snug uppercase rounded shadow-md hover:bg-blue-700 hover:shadow-lg focus:bg-blue-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out"
              @click="login"
              >
              Login
            </button>
           
         


            <p class="text-sm font-semibold mt-2 pt-1 mb-0">
              Don't have an account?
              <a
                href="#!"
                class="text-blue-600 hover:text-red-700 focus:text-red-700 transition duration-200 ease-in-out"
                ><RouterLink to="/SignUp">Register</RouterLink></a
              >
            </p>
          
          </div>
        </form>
      </div>
    </div>
  </div>
</section>
</template>
<script>
import axios from 'axios'
export default{

    name:"Login",
    component:{

    },
    data(){
        return{
          username:"",
          password:"",
          
        
        
        }
    },

    methods:{
      async login(){  
        let user_len=this.password.length;  
        console.log(user_len) 
   if(this.username.length<1 || this.password.length<1){
     alert("Fields must not be empty! ")
   }
   
   else {
 if(this.username.length==7 || this.password.length==6){

 
   try{

    let result1= await axios.get(`http://localhost:5000/signup/${this.username}`)
if(result1){
let checkpswd= JSON.stringify(result1.data[0].password)
        console.log(checkpswd)
      
        let inputpswd=(JSON.stringify(this.password))
        console.log(inputpswd)
if(inputpswd===checkpswd ){
  localStorage.setItem("user-info",this.username)
this.$router.push({name:'TitleSubmission'})
}
else{
  alert("incorrect password! ")
        
      }}}
      catch(err){
        alert("incorrect username! ")

      }
    
}
else if(this.username.length==8 || this.password.length==8){

  try{

let result2= await axios.get(`http://localhost:5000/project_manager/${this.username}`)
if(result2){
let checkpswd= JSON.stringify(result2.data[0].password)
    console.log(checkpswd)
  
    let inputpswd=(JSON.stringify(this.password))
    console.log(inputpswd)
if(inputpswd===checkpswd ){
localStorage.setItem("user-info",this.username)
this.$router.push({name:'FileUpload'})
}
else{
alert("incorrect password! ")
    
  }}}
  catch(err){
    alert("incorrect username! ")

  }

}
}
   }
  
   
      

    }
    

  
  }
 

</script>