<template>
  <div id="app" class="flex justify-center">
  <div class="flex justify-center">
  <div >
        <strong class="text-blue-400"> Find All Resources Here</strong></div>
         
   
  </div>
  </div>
  
<form @submit.prevent="getData">   
   <label for="default-search" class="mb-2 text-sm font-medium text-gray-900 sr-only dark:text-white">Search</label>
   <div class="relative">
       <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
           <svg aria-hidden="true" class="w-5 h-5 text-gray-500 dark:text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
       </div>
       <input type="search" id="default-search" v-model="searchQuery"
       class="block w-full p-4 pl-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-200 dark:border-gray-600 dark:placeholder-gray-400 dark:text-black dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Search here ...." required>
       <input type="submit" class="text-white absolute right-2.5 bottom-2.5 bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-2 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
   </div>
</form>
 
<div class=" flex juastify-center pl-50 w-5/6 "  >
    <table  v-if="resources.length" class=" w-5/6 ml-[440px] text-sm  text-gray-500 dark:text-gray-400">
        <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-blue-500 dark:text-green-400">
            <tr>
                <th scope="col" class="px-6 py-3">
                  Resources
                </th>
             
            </tr>
        </thead>
        <tbody>
            <tr   v-for="item in resultQuery" class="bg-white border-b dark:bg-gray-300 dark:border-gray-300" >
               
                <td  class="px-6 py-4">
                  <a v-bind:href="item.uri" target="_blank">{{item.title}}</a>                </td>
              </tr>
        </tbody>
    </table>
</div>

</template>
<script>
import axios from "axios";

export default{
   name:'ProjectList',
   data() {
   return {
       searchQuery: null,
       resources:[
           
       ]
   };
 },

 created(){
    this.resourcesList();
 },
 methods : {
   async resourcesList() {
     try {
       const response = await axios.get("http://localhost:5000/resources");
       this.resources = response.data;
       console.log(this.resources);
     } catch (err) {
       console.log(err);
     }
   },
 },
 
 computed: {
   resultQuery(){
     if(this.searchQuery){
     return this.resources.filter((item)=>{
       return this.searchQuery.toLowerCase().split(' ').every(v => item.title.toLowerCase().includes(v))
     })
     }else{
       return this.resources;
     }
   }
 }

 
}
</script>