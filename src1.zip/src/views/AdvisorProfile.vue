<template>
    <div class="flex items-center justify-center min-h-screen bg-gray-300">
      <div class="px-8 py-6 mx-4 mt-4 text-left bg-white shadow-lg md:w-1/3 lg:w-1/3 sm:w-1/3">
          <div class="flex justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" class="w-20 h-20 text-blue-600" fill="none" viewBox="0 0 24 24"
                  stroke="currentColor">
                  <path d="M12 14l9-5-9-5-9 5 9 5z" />
                  <path
                      d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z" />
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                      d="M12 14l9-5-9-5-9 5 9 5zm0 0l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14zm-4 6v-7.5l4-2.222" />
              </svg>
          </div>
          <h3 class="text-2xl font-bold text-center">Sign Up </h3>
      <form @submit.prevent="handleSubmission">
          <div class="mt-4">
            <label for="full name" class="">First Name</label>
        <input type="text" v-model="first_name"
         class="w-full px-4 py-2 mt-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600">
        <br>
        <label for="full name" class="">Second Name</label>
        <input type="text" v-model="second_name"
         class="w-full px-4 py-2 mt-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600">
        <br>
        <label for="full name" class="">Last Name</label>
        <input type="text" v-model="last_name"
         class="w-full px-4 py-2 mt-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600">
        <br>

        <div>
        Select Qualification:
        <select v-model="qualification" class="w-full px-4 py-2 mt-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600">>
          <option value="'bsc'">BSC</option>
          <option value="'msc'">MSC</option>
          <option value="'phdegree'">PH degree</option>
          <option value="'professor'">Professor</option>
          <option value="'other'">Other Qualifications</option>
        </select>
      </div>

        <label for="full name" class="">Username</label>
        <input type="text" v-model="username"
         class="w-full px-4 py-2 mt-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600">
        <br>
        <span v-if="msg.name" class="text-red-600">Please fill Up accordingly!</span>
  
        <br>
        <span v-if="msg.name" class="text-red-600">Please fill Up accordingly!</span>
  
        <div>
        Select Your Department :
        <select v-model="department_id" class="w-full px-4 py-2 mt-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600">>
          <option value="1">Computer Engineering</option>
          <option value="2">Electrical Engineering</option>
          <option value="3">Food Engineering</option>
          <option value="4">Chemical Engineering</option>
          <option value="5">Nutrition Engineering</option>
          <option value="6">Mechanical Engineering</option>
          <option value="7">Industrial Engineering</option>
          <option value="8">Automotive Engineering</option>
          <option value="9">Civil Engineering</option>
          <option value="10">Hydrolics and water Resource Engineering</option>
  
  
        </select>
      </div>

      <label for="full name" class="">Email</label>
        <input type="text" v-model="email"
         class="w-full px-4 py-2 mt-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600">
        <br>


  <label for="password" class="block">Password:</label>
        <input type="password" v-model="password" 
        class="w-full px-4 py-2 mt-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600"><br>
        <span v-if="msg.password" class="text-red-600">{{msg.password}}</span>
        <br>
        <label for="twitter" class="block">Confirm Password</label>
        <input type="password" v-model="repassword" 
        class="w-full px-4 py-2 mt-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600 ">
    
        <span v-if="!(this.password==this.repassword)" class="text-red-600 block"> Password Must be the same</span>
        <button type="submit" class="py-2.5 px-5 mr-2 mb-2 text-sm font-medium text-gray-900 focus:outline-none
               bg-white rounded-full border border-gray-200 hover:bg-blue-700 hover:text-white-700 focus:z-10 focus:ring-4
        " @click="handleSubmmit">Submit</button>
        </div>
      </form>
      </div>
  
  </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    name: 'AdvisorProfile',
    data(){
      return {
        first_name:'',
        second_name:'',
        last_name:'',
        username: '',
        department_id:'',
        password: '',
        qualification:'',
        email:'',
        msg: [],
        repassword: '',
        disabled: [true, true]
      }
    },
    watch: {
      email(value){
        // binding this to the data value in the email input
        // this.email = value;
        this.validateEmail(value);
      },
      password(value){
        // this.password = value;
        this.validatePassword(value);
      },
    name(value){
      this.validateName(value)
    }
    },
    methods:{
      validateEmail(value){
        if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(value))
    {
      this.msg['email'] = '';
      this.disabled = [false, this.disabled[1]]
    } else{
      this.msg['email'] = 'Invalid Email Address';
      this.disabled = [true, this.disabled[1]]
    } 
      },
      validatePassword(value){
        let difference = 6 - value.length;
        if (value.length<6) {
          this.msg['password'] = 'Must be 6 characters! '+ difference + ' characters left' ;
          this.disabled = [this.disabled[1], true]
        } else {
           this.msg['password'] = '';
           this.disabled = [this.disabled[1], false]
        }
      },
      validateName(value){
        if(value.length<3){
          this.msg['name']="Not valid name";
        }
        else{
          this.msg['name']='';
        }
      },
    
  
     
     async handleSubmmit(){
      
  
      let result= await axios.post("http://localhost:5000/advisor",{
            first_name:this.first_name,
            second_name:this.second_name,
            last_name:this.last_name,
            department_id:this.department_id,
            username:this.username,
            password:this.password,
            repassword:this.repassword,
            qualification:this.qualification,    
            email:this.email,
          
        });
      
      if( result){
         alert("signup done")
          this.first_name="";
          this.second_name="";
          this.last_name="";
          this.department_id="",
          this.username="",
          this.qualification="",
          this.email="";
          this.password=""
    //   this.$router.push({name:'FileUpload'})
  
       localStorage.setItem("user-info",this.username)
    
           
        }
      
      },
    
      
      mounted(){
        let user=localStorage.getItem('user-info')
        if(user){
          this.$router.push({name:'/'})
        }
      }
  
      }
    }
  
  </script>
  