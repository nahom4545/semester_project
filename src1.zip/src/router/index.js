import { createRouter, createWebHashHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import FileUpload from '../views/FileUpload.vue'
import SignUp from '../views/SignUp.vue'
import Admin from '../views/Admin.vue'
import SearchBar from '../views/SearchBar.vue'
// import UpdateAccount from '../views/UpdateAccount.vue'
import SignAdmin from '../views/SignAdmin.vue'
import ProjectList from '../views/ProjectList.vue'
import DownloadFile from '../views/DownloadFile.vue'
import UploadInfo from '../views/UploadInfo.vue'
import AdvisorProfile from '../views/AdvisorProfile.vue'

import Signlist from '../views/Signlist.vue'
import Notices from '../views/Notices.vue'
import NoticeAdmin from '../views/NoticeAdmin.vue'
import TitleSubmission from '../views/TitleSubmission.vue'
import Login from '../views/Login.vue'
import FormInput from '../views/SignUp.vue'
//import PdfView from '../views/PdfView.vue'
const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView
  },
  
  {
    path: '/FileUpload',
    name: 'FileUpload',
    component: FileUpload
  },
  {
    path: '/SignAdmin',
    name: 'SignAdmin',
    component: SignAdmin
  },
  {
    path: '/NoticeAdmin',
    name: 'NoticeAdmin',
    component: NoticeAdmin
  },
  // {
  //   path: '/UpdateAccount',
  //   name: 'UpdateAccount',
  //   component: UpdateAccount
  // },
  {
    path: '/AdvisorProfile',
    name: 'AdvisorProfile',
    component: AdvisorProfile
  },
  {
    path: '/Signlist',
    name: 'Signlist',
    component: Signlist
  },
  {
    path: '/UploadInfo',
    name: 'UploadInfo',
    component: UploadInfo
  },
  {
    path: '/SignUp',
    name: 'SignUp',
    component: SignUp
  },
  {
    path: '/Admin',
    name: 'Admin',
    component: Admin
  },
  {
    path: '/DownloadFile',
    name: 'DownloadFile',
    component: DownloadFile
  },
  {
    path: '/SearchBar',
    name: 'SearchBar',
    component: SearchBar
  },
  {
    path: '/Notices',
    name: 'Notices',
    component: Notices
  },
  {
    path: '/ProjectList',
    name: 'ProjectList',
    component: ProjectList
  },
  {
    path: '/TitleSubmission',
    name: 'TitleSubmission',
    component: TitleSubmission
  },
  {
    path: '/Login',
    name: 'Login',
    component: Login
  },
  
  {
    path: '/FormInput',
    name: 'FormIput',
    component: FormInput
  },
 /* {
    path: '/PdfView',
    name: 'PdfView',
    component: PdfView
  },
  */
  {
    path: '/about',
    name: 'about',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: function () {
      return import(/* webpackChunkName: "about" */ '../views/AboutView.vue')
    }
  }
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

export default router
